import { AdminRegitserComponent } from '../adminregister/adminregister.component';
import { HomeComponent } from '../home/home.component';
import { AuthGaurdService } from '../guardservice/authguard.service';
import { LogoutComponent } from '../logout/logout.component';
import { LoginComponent } from '../login/login.component';
import { CustomerListComponent } from '../customerlist/customerlist.component';
import { AddCustomerComponent } from '../addcustomer/addcustomer.component';
import { NgModule } from '@angular/core';
import { CanActivate, RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  {path:'add',component:AddCustomerComponent,canActivate:[AuthGaurdService]},
  {path:'view',component:CustomerListComponent,canActivate:[AuthGaurdService]},
  {path:'login',component:LoginComponent},
  {path:'logout',component:LogoutComponent,canActivate:[AuthGaurdService]},
  {path:'',component:HomeComponent},
  {path:'regitser',component:AdminRegitserComponent}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{onSameUrlNavigation:'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
