import { CustomerListComponent } from '../customerlist/customerlist.component';
import { AddCustomerComponent } from '../addcustomer/addcustomer.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'add',component:AddCustomerComponent},
  {path:'view',component:CustomerListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
