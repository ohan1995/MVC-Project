import { HttpClient,HttpErrorResponse,HttpHeaders  } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {User} from './login'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 

@Injectable({
providedIn:'root'

})

export class LoginService{
    constructor(private httpSer:HttpClient) {}
     getAdmin(user:User){
        return this.httpSer.post("http://localhost:9090/admin/login",user)
    }
}