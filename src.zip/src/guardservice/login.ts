export class User{
    username:string
    pass:string
}