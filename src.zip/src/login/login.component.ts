import { AuthenticationService } from '../guardservice/authentication.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../guardservice/login.service';
import { Location } from '@angular/common';
import {User} from '../guardservice/login'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html' 
})
export class LoginComponent implements OnInit {

  user=new User();
  isPresernt:boolean;

  constructor(private router: Router,
    private loginservice: LoginService, private location:Location,private auth:AuthenticationService) { }

  ngOnInit() {
  }

  checkLogin() {
   console.log("saved : "+this.user);
   this.loginservice.getAdmin(this.user).subscribe(
     data =>this.auth.getLoggedIn(data),
     error => this.auth.getLoggedIn(error)

   );
   //alert("User Name or Password incorrect")
   
   this.router.navigate([''])
  }

 goBack() {
    this.location.back();
    console.log( 'goBack()...' );
  }
}