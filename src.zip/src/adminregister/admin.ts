export class User{
    public username='';
    public pass='';
}