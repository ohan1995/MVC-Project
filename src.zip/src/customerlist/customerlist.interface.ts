export interface CustomerList{
    
    custId:number;
    name:string;
    email:string;
    phone:number;
}