export class User{
public custId =''
public name =''
public email =''
public phone=''


}
   