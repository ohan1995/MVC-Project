import { config } from 'rxjs/internal-compatibility';
import {HttpClient} from '@angular/common/http';
import {User} from './addcustomer';
import {Injectable} from '@angular/core';

@Injectable({providedIn:'root'})

export class AddcustomerService{
    constructor(private httpser:HttpClient){}

    config = {header :{
        "Content-type":"application/json;charset=utf-8"
    }}

    url="http"//localhost
}