import { Router } from '@angular/router';
import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/forms'
import {User} from './addcustomer'
import {HttpClient} from '@angular/common/http';
import {AddCustomerService} from './addcustomer.service'
import { Location } from '@angular/common';


@Component({
    selector:'loginform',
    templateUrl:'./addcustomer.component.html'
})
export class AddCustomerComponent {

    add= new User();

    constructor(private custservice:AddCustomerService,private router:Router,private location:Location){}

    save(addForm:NgForm){
        console.log(addForm.form);
        //console.log('save data' + JSON.stringify(addForm.value))
        console.log('data'+this.add)
        this.custservice.addCustomer(this.add).subscribe(
            data => console.log('success!!',data),
            error => console.log('error!!',error)
        )
        this.router.navigate(['/view'])
    }
    goBack() {
    this.location.back();
    console.log( 'goBack()...' );
  }
}