import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/forms'
import {User} from './addcustomer'
import {ActivatedRoute,Router} from '@angular/router'
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {AddcustomerService} from './addcustomer.service'

@Component({
    selector:'adduser',
    templateUrl:'./addcustomer.component.html'
})
export class AddCustomerComponent implements OnInit {
ngOnInit(): void {
  
}
constructor(private route:ActivatedRoute,private router:Router,private httpser:HttpClient,private custservice:AddcustomerService){}

user = new User()

    save(customerForm:NgForm){
        console.log("saved form "+this.user);
        this.custservice.add(this.user).subscribe(data => console.log("success!!" , data),
        error => console.log("Error!!",error))
        console.log('save data' + JSON.stringify(customerForm.value))
    }
}