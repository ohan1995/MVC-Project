package com.Banking.BankingSpring.controller;
import java.util.*;


import javax.validation.Valid;

import org.springframework.web.bind.annotation.RequestMapping;

import com.Banking.BankingSpring.dao.*;
import com.Banking.BankingSpring.model.*;
import com.Banking.BankingSpring.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService service;
	
	
	@GetMapping("hello")
	public List<Customer> getAllCustomer(){
		System.out.println("Request Received");
		return (List<Customer>) service.getAllCustomer();
	}
	
	@PostMapping("add")
	public Customer createCustomer(@RequestBody Customer customer) {
		return service.createCustomer(customer);
	}
	
	@DeleteMapping("delete/{custId}")
	public Customer delete(@PathVariable("custId") int custId,Customer customer) {
		customer.setCustId(custId);
		return service.delete(custId);
	}
}
