package com.Banking.BankingSpring.controller;
import java.util.*;



import org.springframework.web.bind.annotation.RequestMapping;

import com.Banking.BankingSpring.model.*;
import com.Banking.BankingSpring.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService service;
	
	
	@GetMapping("hello")
	public List<Customer> getAllCustomer(){
		System.out.println("Request Received");
		return (List<Customer>) service.getAllCustomer();
	}
	
	@PostMapping("add")
	//@CrossOrigin(origins = "http://localhost:4200")
	public Customer createCustomer(@RequestBody Customer customer) {
		System.out.println("Before");
		return service.createCustomer(customer);
	}
	
	@DeleteMapping("delete/{custId}")
	public Customer delete(@PathVariable("custId") int custId,Customer customer) {
		System.out.println(custId);
		customer.setCustId(custId);
		System.out.println("Delete Record");
		return service.delete(custId);
	}
}
