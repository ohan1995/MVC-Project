package com.Banking.BankingSpring.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Banking.BankingSpring.dao.CustomerDao;
import com.Banking.BankingSpring.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDao dao;

	@Override
	public List<Customer> getAllCustomer() {
		List<Customer> customer=new ArrayList<Customer>();
		Iterator<Customer> iterator = dao.findAll().iterator();
		while(iterator.hasNext()) {
			customer.add(iterator.next());
		}
		return customer;
	}

	@Override
	public Customer createCustomer(Customer customer) {
		return dao.save(customer);
	}

	@Override
	public Customer delete(int custId) {
	
	        Customer customer = dao.getOne(custId);
	        if(customer != null){
	            dao.delete(customer);
	        }
	        return customer;
		
	}
	
	
}
