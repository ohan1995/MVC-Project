package com.Banking.BankingSpring.service;


import com.Banking.BankingSpring.model.Admin;

public interface AdminService {
	Boolean getAdmin(Admin admin);
	Admin createAdmin(Admin admin);
}
