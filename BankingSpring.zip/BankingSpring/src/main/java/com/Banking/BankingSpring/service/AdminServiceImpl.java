package com.Banking.BankingSpring.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Banking.BankingSpring.dao.AdminDao;
import com.Banking.BankingSpring.model.Admin;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminDao dao;

	@Override
	public Boolean getAdmin(Admin admin) {
		System.out.println("before find all");
		List<Admin> adminList =(List<Admin>) dao.findAll();
		System.out.println(admin.username +" " +admin.pass );
		boolean isPresent=false;
		
		for(int i=0;i<adminList.size();i++) {
			if((admin.username).equals(adminList.get(i).username)){
				if((admin.pass).equals(adminList.get(i).pass)){
					isPresent=true;
					System.out.println("Hello"); 
				}
			}
		}
		return isPresent;
	}

	@Override
	public Admin createAdmin(Admin admin) {
		try {
		return dao.save(admin);
		}catch(Exception e) {
			System.out.println("Exception occur");
			 return null;
		}
		}
	}

