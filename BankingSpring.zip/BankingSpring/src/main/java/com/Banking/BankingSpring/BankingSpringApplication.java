package com.Banking.BankingSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingSpringApplication.class, args);
	}

}
