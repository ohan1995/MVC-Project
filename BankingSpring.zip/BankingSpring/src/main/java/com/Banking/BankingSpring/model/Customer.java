package com.Banking.BankingSpring.model;

import javax.persistence.*;

@Entity
@Table(name="add_user")
public class Customer {
	@Id
	private int custId;
	@Column(name = "name")
	private String name;
	@Column(name = "email")
	private String email;
	@Column(name = "phone")
	private long phone;
	
	public Customer(){
		
	}
	
	public Customer(int custId, String name, String email, long phone) {
		this.custId = custId;
		this.name = name;
		this.email = email;
		this.phone = phone;
	}

	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", email=" + email + ", phone=" + phone + "]";
	}
}
