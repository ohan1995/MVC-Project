package com.Banking.BankingSpring.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Banking.BankingSpring.model.Admin;
import com.Banking.BankingSpring.service.AdminService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService service;
	
	@PostMapping("login")
	public Boolean getAdmin(@RequestBody Admin admin){
		System.out.println("Request Received");
		return service.getAdmin(admin);
	}
	
	@PostMapping("add")
	//@CrossOrigin(origins = "http://localhost:4200")
	public Admin createAdmin(@RequestBody Admin admin) {
		System.out.println("Add Admin");
		return service.createAdmin(admin);
	}
}
