package com.Banking.BankingSpring.service;

import com.Banking.BankingSpring.model.*;

import java.util.List;
public interface CustomerService {
	List<Customer> getAllCustomer();
	Customer createCustomer(Customer customer);
	Customer delete(Integer custId);
}
