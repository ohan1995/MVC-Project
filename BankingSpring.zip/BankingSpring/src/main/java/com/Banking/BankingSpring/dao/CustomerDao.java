package com.Banking.BankingSpring.dao;




import org.springframework.data.jpa.repository.JpaRepository;

import com.Banking.BankingSpring.model.*;

public interface CustomerDao extends JpaRepository<Customer, Integer> {


}

