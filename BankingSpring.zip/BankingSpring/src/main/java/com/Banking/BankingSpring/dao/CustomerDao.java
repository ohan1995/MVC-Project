package com.Banking.BankingSpring.dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.Banking.BankingSpring.model.*;

public interface CustomerDao extends JpaRepository<Customer, Integer> {


}

